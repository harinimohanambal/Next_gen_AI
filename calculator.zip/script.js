const display = document.getElementById('display');

let current = '0';
let previous = null;
let operator = null;
let overwrite = true; // next digit press replaces the display instead of appending

function updateDisplay() {
  display.classList.remove('error');
  let text = current;
  // avoid overflowing the display with long floats
  if (!isNaN(parseFloat(text)) && text.length > 12 && text.includes('.')) {
    text = parseFloat(text).toPrecision(10).replace(/\.?0+$/, '');
  }
  display.textContent = text;
}

function showError() {
  display.classList.add('error');
  display.textContent = 'Error';
  current = '0';
  previous = null;
  operator = null;
  overwrite = true;
}

function inputDigit(d) {
  if (overwrite) {
    current = d === '.' ? '0.' : d;
    overwrite = false;
    return;
  }
  if (d === '.' && current.includes('.')) return; // guard: one decimal point
  if (current === '0' && d !== '.') {
    current = d;
  } else {
    current += d;
  }
}

function compute(a, b, op) {
  switch (op) {
    case 'add': return a + b;
    case 'subtract': return a - b;
    case 'multiply': return a * b;
    case 'divide': return b === 0 ? null : a / b;
    default: return b;
  }
}

function chooseOperator(op) {
  if (operator && !overwrite) {
    equals();
  }
  previous = parseFloat(current);
  operator = op;
  overwrite = true;
}

function equals() {
  if (operator === null || previous === null) return;
  const result = compute(previous, parseFloat(current), operator);
  if (result === null) {
    showError();
    return;
  }
  current = String(result);
  operator = null;
  previous = null;
  overwrite = true;
}

function clearAll() {
  current = '0';
  previous = null;
  operator = null;
  overwrite = true;
}

function toggleSign() {
  if (current === '0') return;
  current = current.startsWith('-') ? current.slice(1) : '-' + current;
}

function percent() {
  const value = parseFloat(current);
  current = String(previous !== null ? (previous * value) / 100 : value / 100);
}

function handleAction(action) {
  switch (action) {
    case 'clear': clearAll(); break;
    case 'sign': toggleSign(); break;
    case 'percent': percent(); break;
    case 'equals': equals(); break;
    case 'add':
    case 'subtract':
    case 'multiply':
    case 'divide':
      chooseOperator(action);
      break;
  }
  updateDisplay();
}

document.querySelectorAll('.btn[data-value]').forEach(btn => {
  btn.addEventListener('click', () => {
    inputDigit(btn.dataset.value);
    updateDisplay();
  });
});

document.querySelectorAll('.btn[data-action]').forEach(btn => {
  btn.addEventListener('click', () => handleAction(btn.dataset.action));
});

const keyMap = {
  '+': 'add',
  '-': 'subtract',
  '*': 'multiply',
  '/': 'divide',
  'Enter': 'equals',
  '=': 'equals',
  'Escape': 'clear',
  'c': 'clear',
  'C': 'clear',
  '%': 'percent',
};

window.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') {
    inputDigit(e.key);
    updateDisplay();
    return;
  }
  if (e.key === '.') {
    inputDigit('.');
    updateDisplay();
    return;
  }
  if (e.key === 'Backspace') {
    current = current.length > 1 ? current.slice(0, -1) : '0';
    if (current === '-') current = '0';
    updateDisplay();
    return;
  }
  if (keyMap[e.key]) {
    e.preventDefault();
    handleAction(keyMap[e.key]);
  }
});

updateDisplay();
